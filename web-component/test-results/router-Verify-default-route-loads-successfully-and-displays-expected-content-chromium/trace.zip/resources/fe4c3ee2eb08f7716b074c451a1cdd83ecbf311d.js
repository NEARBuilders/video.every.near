import r from"base-x";var a={};var v=r;var e="123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";a=v(e);var o=a;export default o;

//# sourceMappingURL=index.js.map