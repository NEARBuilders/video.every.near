import e from"./index.js";e.check("es5");var r={};export default r;

//# sourceMappingURL=es5.js.map