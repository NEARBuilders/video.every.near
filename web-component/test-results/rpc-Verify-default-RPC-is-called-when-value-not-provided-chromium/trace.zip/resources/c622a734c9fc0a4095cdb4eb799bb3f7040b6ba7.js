var e={};e=(e,t)=>{if(!("string"===typeof e&&"string"===typeof t))throw new TypeError("Expected the arguments to be of type `string`");if(""===t)return[e];const r=e.indexOf(t);return-1===r?[e]:[e.slice(0,r),e.slice(r+t.length)]};var t=e;export default t;

//# sourceMappingURL=index.js.map