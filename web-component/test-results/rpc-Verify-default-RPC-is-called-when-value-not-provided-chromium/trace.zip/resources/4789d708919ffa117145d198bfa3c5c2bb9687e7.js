var r={};r=function(r,a){var v={};var e=Object.keys(r);var t=Array.isArray(a);for(var n=0;n<e.length;n++){var f=e[n];var i=r[f];(t?-1!==a.indexOf(f):a(f,i,r))&&(v[f]=i)}return v};var a=r;export default a;

//# sourceMappingURL=index.js.map