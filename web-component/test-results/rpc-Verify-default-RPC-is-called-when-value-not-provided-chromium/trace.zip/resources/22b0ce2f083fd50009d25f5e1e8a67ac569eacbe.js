var e={};e=e=>encodeURIComponent(e).replace(/[!'()*]/g,e=>`%${e.charCodeAt(0).toString(16).toUpperCase()}`);var o=e;export default o;

//# sourceMappingURL=index.js.map