var r={};r=Object.setPrototypeOf||({__proto__:[]}instanceof Array?setProtoOf:mixinProperties);function setProtoOf(r,t){r.__proto__=t;return r}function mixinProperties(r,t){for(var o in t)Object.prototype.hasOwnProperty.call(r,o)||(r[o]=t[o]);return r}var t=r;export default t;

//# sourceMappingURL=index.js.map